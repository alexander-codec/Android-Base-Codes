package com.dmbteam.scheduler.util;

/**
 * Created by dobrikostadinov on 5/10/15.
 */
public class Constants {

    public static final String KEY_DBITEM_ID = "db.item.id";

    public static final String KEY_RECEIVER_REFRESH = "key.receiver.refresh";

    public static final String ACTION_REFRESH = "action.refresh";
}
